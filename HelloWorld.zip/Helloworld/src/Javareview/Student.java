package Javareview;

public class Student {
    // การสร้าง class
    // -----access specifier/ access modifier ---------
    // -----ตัวระบุการเช้าถึงตำแหน่งเมทอด มี  4 ระดับ
    // private คลาสภายในเข้าถึงเท่านั้น
    // ,public สาธารณะ ,package (default), protacted


    //  1 ----- field, attribute ,instance variable  -------
    private int id;
    private String name;
    private double midtermScore;
    private double finalScore;

    //  2 -----  constructor  -----
    //  กำหนดค่าเริ่มต้น object ให้กับ field ต่างๆ
    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    //   3 ----- method คล้ายฟังชั่น ประมวลผลข้อมูล -----
    //    method มี 2 ส่วน คือ
    //    1.method ที่มีการประมวลผลตัว instance variable
    //    2.method ที่เป็น getter , setter

    public double getTotalScore() {
        double total = midtermScore + finalScore;
        return total;
    }

    // getters อ่านข้อมูล
    public int getId() {
        return id;
    }

    public String getName() {

        return name;
    }

    // setters  กำหนดค่า
    public void setName(String name) {

        this.name = name;
    }

    public void setMidtermScore(double midtermScore) {
        this.midtermScore = midtermScore;
    }

    public void setFinalScore(double finalScore) {
        this.finalScore = finalScore;
    }

    //toString method  พิมพ์ ข้อมูลออกมาได้ง่าย
    public String toString(){
        return id + " -- " + name;

    }

}

