package Javareview;

public class StudentMain {

    public static void main(String[] args) {

        Student kwan = new Student(1, "Kwan");
        Student kate = new Student(2, "Kate");

       // System.out.println(kwan.getId() + " : " + kwan.getName());
        System.out.println(kwan);
        // System.out.println(kate.getId() + " : " + kate.getName());
        System.out.println(kate);

        kwan.setMidtermScore(10);
        kwan.setFinalScore(8);
        System.out.println("Kwan's total = " + kwan.getTotalScore());
    }
}

//        int x = 5;
//      kwan.id = 1;
//       kwan.name = "Kwan";
//        kate.id = 2;
//        kate.name = "kate";
//        Student s = kwan;
//        s.id = 100;
//        System.out.println(kwan.id + " : " + kwan.name);
